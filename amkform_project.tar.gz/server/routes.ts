import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPersonnelSchema } from "@shared/schema";
import multer from "multer";
import * as XLSX from "xlsx";
import { z } from "zod";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedMimes = [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
      'application/vnd.ms-excel' // .xls
    ];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Type de fichier non supporté. Formats acceptés: .xlsx, .docx'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all personnel
  app.get("/api/personnel", async (req, res) => {
    try {
      const { search } = req.query;
      let personnel;
      
      if (search && typeof search === 'string') {
        personnel = await storage.searchPersonnel(search);
      } else {
        personnel = await storage.getAllPersonnel();
      }
      
      res.json(personnel);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération du personnel" });
    }
  });

  // Get statistics for export panel
  app.get("/api/personnel/stats", async (req, res) => {
    try {
      const allPersonnel = await storage.getAllPersonnel();
      
      const bankCounts = allPersonnel.reduce((acc, p) => {
        acc[p.banque] = (acc[p.banque] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const marketCounts = allPersonnel.reduce((acc, p) => {
        acc[p.numeroMarcheCadre] = (acc[p.numeroMarcheCadre] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      res.json({
        total: allPersonnel.length,
        byBank: bankCounts,
        byMarket: marketCounts,
        lastUpdate: allPersonnel.length > 0 ? allPersonnel[0].createdAt : null
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération des statistiques" });
    }
  });

  // Get personnel by ID
  app.get("/api/personnel/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const person = await storage.getPersonnel(id);
      
      if (!person) {
        return res.status(404).json({ message: "Personnel non trouvé" });
      }
      
      res.json(person);
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la récupération du personnel" });
    }
  });

  // Create personnel
  app.post("/api/personnel", async (req, res) => {
    try {
      const validatedData = insertPersonnelSchema.parse(req.body);
      const person = await storage.createPersonnel(validatedData);
      res.status(201).json(person);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Données invalides", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Erreur lors de la création du personnel" });
    }
  });

  // Update personnel
  app.put("/api/personnel/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertPersonnelSchema.partial().parse(req.body);
      const person = await storage.updatePersonnel(id, validatedData);
      
      if (!person) {
        return res.status(404).json({ message: "Personnel non trouvé" });
      }
      
      res.json(person);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Données invalides", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Erreur lors de la mise à jour du personnel" });
    }
  });

  // Delete personnel
  app.delete("/api/personnel/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deletePersonnel(id);
      
      if (!success) {
        return res.status(404).json({ message: "Personnel non trouvé" });
      }
      
      res.json({ message: "Personnel supprimé avec succès" });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de la suppression du personnel" });
    }
  });

  // File upload and import
  app.post("/api/personnel/import", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "Aucun fichier fourni" });
      }

      let data: any[][] = [];
      
      if (req.file.mimetype.includes('spreadsheet') || req.file.mimetype.includes('excel')) {
        // Parse Excel file
        const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        data = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      } else {
        return res.status(400).json({ message: "Format de fichier non supporté pour l'import" });
      }

      if (data.length < 2) {
        return res.status(400).json({ message: "Le fichier doit contenir au moins une ligne d'en-têtes et une ligne de données" });
      }

      const headers = data[0].map((h: any) => String(h).toLowerCase().trim());
      const rows = data.slice(1);

      // Expected columns mapping
      const columnMapping = {
        nom: ['nom', 'name', 'lastname'],
        prenom: ['prénom', 'prenom', 'firstname'],
        cin: ['cin', 'id', 'carte identité'],
        compteBancaire: ['compte bancaire', 'compte', 'account', 'bank account'],
        banque: ['banque', 'bank'],
        numeroMarcheCadre: ['numéro du marché cadre', 'numero marche cadre', 'marché cadre', 'marche cadre'],
        montantPaiement: ['montant du paiement', 'montant paiement', 'montant', 'amount']
      };

      const columnIndexes: { [key: string]: number } = {};
      
      // Find column indexes
      for (const [field, variations] of Object.entries(columnMapping)) {
        const index = headers.findIndex((header: string) => 
          variations.some(variation => header.includes(variation))
        );
        if (index !== -1) {
          columnIndexes[field] = index;
        }
      }

      // Validate required columns
      const requiredFields = ['nom', 'prenom', 'cin', 'compteBancaire', 'banque', 'numeroMarcheCadre', 'montantPaiement'];
      const missingFields = requiredFields.filter(field => columnIndexes[field] === undefined);
      
      if (missingFields.length > 0) {
        return res.status(400).json({ 
          message: `Colonnes manquantes: ${missingFields.join(', ')}`,
          expectedColumns: requiredFields
        });
      }

      // Parse rows
      const parsedData = [];
      const errors = [];

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        if (row.length === 0 || row.every((cell: any) => !cell)) continue; // Skip empty rows

        try {
          const personnelData = {
            nom: String(row[columnIndexes.nom] || '').trim(),
            prenom: String(row[columnIndexes.prenom] || '').trim(),
            cin: String(row[columnIndexes.cin] || '').trim(),
            compteBancaire: String(row[columnIndexes.compteBancaire] || '').trim(),
            banque: String(row[columnIndexes.banque] || '').trim(),
            numeroMarcheCadre: String(row[columnIndexes.numeroMarcheCadre] || '').trim(),
            montantPaiement: String(row[columnIndexes.montantPaiement] || '').replace(/[^\d.,]/g, '').replace(',', '.'),
            statut: "En attente"
          };

          // Validate data
          const validated = insertPersonnelSchema.parse(personnelData);
          parsedData.push({ ...validated, rowIndex: i + 2 }); // +2 for header and 0-based index
        } catch (error) {
          errors.push({
            row: i + 2,
            error: error instanceof z.ZodError ? error.errors : String(error)
          });
        }
      }

      res.json({
        success: true,
        data: parsedData,
        errors: errors,
        totalRows: rows.length,
        validRows: parsedData.length,
        errorRows: errors.length
      });

    } catch (error) {
      console.error('Import error:', error);
      res.status(500).json({ message: "Erreur lors de l'import du fichier" });
    }
  });

  // Confirm import (save validated data)
  app.post("/api/personnel/import/confirm", async (req, res) => {
    try {
      const { data } = req.body;
      
      if (!Array.isArray(data) || data.length === 0) {
        return res.status(400).json({ message: "Aucune donnée à importer" });
      }

      const results = await storage.createBulkPersonnel(data);
      res.json({
        message: `${results.length} enregistrements importés avec succès`,
        imported: results
      });
    } catch (error) {
      res.status(500).json({ message: "Erreur lors de l'import des données" });
    }
  });

  // Export data
  app.get("/api/personnel/export/:type", async (req, res) => {
    try {
      const { type } = req.params;
      let data: any[] = [];
      let filename = '';

      switch (type) {
        case 'global':
          data = await storage.getAllPersonnel();
          filename = 'personnel_global.xlsx';
          break;
        case 'bank':
          const { bank } = req.query;
          if (!bank) {
            return res.status(400).json({ message: "Paramètre 'bank' requis" });
          }
          data = await storage.getPersonnelByBank(String(bank));
          filename = `personnel_${String(bank).replace(/\s+/g, '_')}.xlsx`;
          break;
        case 'market':
          const { marketFrame } = req.query;
          if (!marketFrame) {
            return res.status(400).json({ message: "Paramètre 'marketFrame' requis" });
          }
          data = await storage.getPersonnelByMarcheCadre(String(marketFrame));
          filename = `personnel_marche_${String(marketFrame).replace(/\s+/g, '_')}.xlsx`;
          break;
        default:
          return res.status(400).json({ message: "Type d'export invalide" });
      }

      // Create Excel workbook
      const worksheet = XLSX.utils.json_to_sheet(data.map(p => ({
        'Nom': p.nom,
        'Prénom': p.prenom,
        'CIN': p.cin,
        'Compte Bancaire': p.compteBancaire,
        'Banque': p.banque,
        'Numéro Marché Cadre': p.numeroMarcheCadre,
        'Montant Paiement': p.montantPaiement,
        'Statut': p.statut,
        'Date Création': p.createdAt
      })));

      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Personnel');

      const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(buffer);

    } catch (error) {
      res.status(500).json({ message: "Erreur lors de l'export des données" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
