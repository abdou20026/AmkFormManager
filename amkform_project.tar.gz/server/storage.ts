import { personnel, type Personnel, type InsertPersonnel } from "@shared/schema";

export interface IStorage {
  getPersonnel(id: number): Promise<Personnel | undefined>;
  getAllPersonnel(): Promise<Personnel[]>;
  getPersonnelByBank(banque: string): Promise<Personnel[]>;
  getPersonnelByMarcheCadre(numeroMarcheCadre: string): Promise<Personnel[]>;
  createPersonnel(data: InsertPersonnel): Promise<Personnel>;
  updatePersonnel(id: number, data: Partial<InsertPersonnel>): Promise<Personnel | undefined>;
  deletePersonnel(id: number): Promise<boolean>;
  createBulkPersonnel(data: InsertPersonnel[]): Promise<Personnel[]>;
  searchPersonnel(query: string): Promise<Personnel[]>;
}

export class MemStorage implements IStorage {
  private personnel: Map<number, Personnel>;
  private currentId: number;

  constructor() {
    this.personnel = new Map();
    this.currentId = 1;
  }

  async getPersonnel(id: number): Promise<Personnel | undefined> {
    return this.personnel.get(id);
  }

  async getAllPersonnel(): Promise<Personnel[]> {
    return Array.from(this.personnel.values()).sort((a, b) => 
      new Date(b.createdAt || "").getTime() - new Date(a.createdAt || "").getTime()
    );
  }

  async getPersonnelByBank(banque: string): Promise<Personnel[]> {
    return Array.from(this.personnel.values()).filter(p => p.banque === banque);
  }

  async getPersonnelByMarcheCadre(numeroMarcheCadre: string): Promise<Personnel[]> {
    return Array.from(this.personnel.values()).filter(p => p.numeroMarcheCadre === numeroMarcheCadre);
  }

  async createPersonnel(insertData: InsertPersonnel): Promise<Personnel> {
    const id = this.currentId++;
    const now = new Date().toISOString();
    const person: Personnel = { 
      ...insertData, 
      id, 
      createdAt: now,
      statut: insertData.statut || "En attente"
    };
    this.personnel.set(id, person);
    return person;
  }

  async updatePersonnel(id: number, data: Partial<InsertPersonnel>): Promise<Personnel | undefined> {
    const existing = this.personnel.get(id);
    if (!existing) return undefined;
    
    const updated: Personnel = { ...existing, ...data };
    this.personnel.set(id, updated);
    return updated;
  }

  async deletePersonnel(id: number): Promise<boolean> {
    return this.personnel.delete(id);
  }

  async createBulkPersonnel(data: InsertPersonnel[]): Promise<Personnel[]> {
    const results: Personnel[] = [];
    for (const item of data) {
      const person = await this.createPersonnel(item);
      results.push(person);
    }
    return results;
  }

  async searchPersonnel(query: string): Promise<Personnel[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.personnel.values()).filter(p => 
      p.nom.toLowerCase().includes(lowerQuery) ||
      p.prenom.toLowerCase().includes(lowerQuery) ||
      p.cin.toLowerCase().includes(lowerQuery) ||
      p.banque.toLowerCase().includes(lowerQuery) ||
      p.numeroMarcheCadre.toLowerCase().includes(lowerQuery)
    );
  }
}

export const storage = new MemStorage();
