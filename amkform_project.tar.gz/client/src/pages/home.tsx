import Header from "@/components/header";
import ImportSection from "@/components/import-section";
import DataPreview from "@/components/data-preview";
import PersonnelTable from "@/components/personnel-table";
import ExportPanel from "@/components/export-panel";
import DeleteDialog from "@/components/delete-dialog";
import AddPersonnelDialog from "@/components/add-personnel-dialog";
import { useState } from "react";
import { Personnel } from "@shared/schema";

export default function Home() {
  const [previewData, setPreviewData] = useState<any[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedPerson, setSelectedPerson] = useState<Personnel | null>(null);
  const [addDialogOpen, setAddDialogOpen] = useState(false);

  const handleImportPreview = (data: any[]) => {
    setPreviewData(data);
    setShowPreview(true);
  };

  const handlePreviewClose = () => {
    setShowPreview(false);
    setPreviewData([]);
  };

  const handleDeleteClick = (person: Personnel) => {
    setSelectedPerson(person);
    setDeleteDialogOpen(true);
  };

  const handleDeleteClose = () => {
    setDeleteDialogOpen(false);
    setSelectedPerson(null);
  };

  const handleAddClick = () => {
    setAddDialogOpen(true);
  };

  const handleAddClose = () => {
    setAddDialogOpen(false);
  };

  return (
    <div className="min-h-screen bg-amk-background">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ImportSection onImportPreview={handleImportPreview} />
        
        {showPreview && (
          <DataPreview 
            data={previewData} 
            onClose={handlePreviewClose}
          />
        )}
        
        <PersonnelTable onDeleteClick={handleDeleteClick} onAddClick={handleAddClick} />
        
        <ExportPanel />
      </main>

      <DeleteDialog
        open={deleteDialogOpen}
        onClose={handleDeleteClose}
        person={selectedPerson}
      />

      <AddPersonnelDialog
        open={addDialogOpen}
        onClose={handleAddClose}
      />
    </div>
  );
}
