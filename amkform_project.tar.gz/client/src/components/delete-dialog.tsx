import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AlertTriangle } from "lucide-react";
import { Personnel } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DeleteDialogProps {
  open: boolean;
  onClose: () => void;
  person: Personnel | null;
}

export default function DeleteDialog({ open, onClose, person }: DeleteDialogProps) {
  const { toast } = useToast();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/personnel/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Suppression réussie",
        description: "L'enregistrement a été supprimé avec succès"
      });
      queryClient.invalidateQueries({ queryKey: ['/api/personnel'] });
      queryClient.invalidateQueries({ queryKey: ['/api/personnel/stats'] });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Erreur de suppression",
        description: error instanceof Error ? error.message : "Erreur inconnue",
        variant: "destructive"
      });
    }
  });

  const handleConfirmDelete = () => {
    if (person) {
      deleteMutation.mutate(person.id);
    }
  };

  if (!person) return null;

  return (
    <AlertDialog open={open} onOpenChange={onClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mr-4">
              <AlertTriangle className="text-red-600 h-6 w-6" />
            </div>
            <div>
              <AlertDialogTitle className="text-lg font-semibold text-gray-900">
                Confirmer la suppression
              </AlertDialogTitle>
              <AlertDialogDescription className="text-gray-600 text-sm">
                Cette action est irréversible
              </AlertDialogDescription>
            </div>
          </div>
        </AlertDialogHeader>
        
        <div className="text-gray-700 mb-6">
          Voulez-vous vraiment supprimer l'enregistrement de{' '}
          <strong>{person.prenom} {person.nom}</strong> ?
        </div>
        
        <AlertDialogFooter>
          <AlertDialogCancel onClick={onClose}>
            Annuler
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleConfirmDelete}
            disabled={deleteMutation.isPending}
            className="bg-red-600 hover:bg-red-700"
          >
            {deleteMutation.isPending ? 'Suppression...' : 'Supprimer'}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
