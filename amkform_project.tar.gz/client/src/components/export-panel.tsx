import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileSpreadsheet, Globe, Building2, Briefcase, Download } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

interface StatsData {
  total: number;
  byBank: Record<string, number>;
  byMarket: Record<string, number>;
  lastUpdate: string | null;
}

export default function ExportPanel() {
  const { data: stats } = useQuery<StatsData>({
    queryKey: ['/api/personnel/stats'],
    queryFn: async () => {
      const response = await fetch('/api/personnel/stats', { credentials: 'include' });
      if (!response.ok) throw new Error('Erreur lors du chargement des statistiques');
      return response.json();
    }
  });

  const handleExport = (type: 'global' | 'bank' | 'market', param?: string) => {
    let url = `/api/personnel/export/${type}`;
    if (param) {
      url += `?${type === 'bank' ? 'bank' : 'marketFrame'}=${encodeURIComponent(param)}`;
    }
    window.open(url, '_blank');
  };

  const handleExportByBank = (bank: string) => {
    const url = `/api/personnel/export/bank?bank=${encodeURIComponent(bank)}`;
    window.open(url, '_blank');
  };

  const handleExportByMarket = (market: string) => {
    const url = `/api/personnel/export/market?marketFrame=${encodeURIComponent(market)}`;
    window.open(url, '_blank');
  };

  const lastUpdateText = stats?.lastUpdate 
    ? formatDistanceToNow(new Date(stats.lastUpdate), { addSuffix: true, locale: fr })
    : 'Jamais';

  return (
    <Card className="mt-8">
      <CardHeader className="border-b border-gray-200">
        <CardTitle className="flex items-center text-xl font-semibold text-gray-900">
          <FileSpreadsheet className="text-amk-primary mr-3 h-5 w-5" />
          Gestion des exports automatiques
        </CardTitle>
        <p className="text-gray-600">Fichiers générés automatiquement lors des modifications</p>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Global Export */}
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-6 border border-blue-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 amk-primary rounded-lg flex items-center justify-center">
                <Globe className="text-white h-6 w-6" />
              </div>
              <Badge className="bg-green-100 text-green-800">
                Actif
              </Badge>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Fichier global</h3>
            <p className="text-sm text-gray-600 mb-4">
              {stats?.total || 0} enregistrements au total
            </p>
            <div className="text-xs text-gray-500 mb-3">
              Dernière mise à jour: {lastUpdateText}
            </div>
            <Button 
              onClick={() => handleExport('global')}
              className="w-full amk-primary hover:amk-primary-dark text-white text-sm"
            >
              <Download className="mr-2 h-4 w-4" />
              Télécharger
            </Button>
          </div>

          {/* Bank Export */}
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-6 border border-green-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 amk-secondary rounded-lg flex items-center justify-center">
                <Building2 className="text-white h-6 w-6" />
              </div>
              <Badge className="bg-green-100 text-green-800">
                Actif
              </Badge>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Par banque</h3>
            <p className="text-sm text-gray-600 mb-4">
              {Object.keys(stats?.byBank || {}).length} banques différentes
            </p>
            <div className="text-xs text-gray-500 mb-3 max-h-16 overflow-y-auto space-y-1">
              {stats?.byBank && Object.entries(stats.byBank).map(([bank, count]) => (
                <div key={bank} className="flex justify-between items-center">
                  <span className="truncate text-xs">{bank}</span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleExportByBank(bank)}
                    className="h-6 px-2 text-xs text-green-700 hover:bg-green-50"
                  >
                    Excel ({count})
                  </Button>
                </div>
              ))}
            </div>
            <Button 
              onClick={() => handleExport('global')}
              className="w-full amk-secondary hover:bg-green-700 text-white text-sm"
            >
              <Download className="mr-2 h-4 w-4" />
              Toutes les banques (Excel)
            </Button>
          </div>

          {/* Market Frame Export */}
          <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg p-6 border border-amber-200">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 amk-accent rounded-lg flex items-center justify-center">
                <Briefcase className="text-white h-6 w-6" />
              </div>
              <Badge className="bg-green-100 text-green-800">
                Actif
              </Badge>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Par marché cadre</h3>
            <p className="text-sm text-gray-600 mb-4">
              {Object.keys(stats?.byMarket || {}).length} marchés actifs
            </p>
            <div className="text-xs text-gray-500 mb-3 max-h-16 overflow-y-auto space-y-1">
              {stats?.byMarket && Object.entries(stats.byMarket).map(([market, count]) => (
                <div key={market} className="flex justify-between items-center">
                  <span className="truncate text-xs">{market}</span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleExportByMarket(market)}
                    className="h-6 px-2 text-xs text-orange-700 hover:bg-orange-50"
                  >
                    Excel ({count})
                  </Button>
                </div>
              ))}
            </div>
            <Button 
              onClick={() => handleExport('global')}
              className="w-full amk-accent hover:bg-orange-600 text-white text-sm"
            >
              <Download className="mr-2 h-4 w-4" />
              Tous les marchés (Excel)
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
