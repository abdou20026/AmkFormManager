import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Eye, AlertCircle, X } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface DataPreviewProps {
  data: any[];
  onClose: () => void;
}

export default function DataPreview({ data, onClose }: DataPreviewProps) {
  const { toast } = useToast();

  const confirmImportMutation = useMutation({
    mutationFn: async (importData: any[]) => {
      const response = await apiRequest('POST', '/api/personnel/import/confirm', { data: importData });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Import confirmé",
        description: `${data.length} enregistrements importés avec succès`
      });
      queryClient.invalidateQueries({ queryKey: ['/api/personnel'] });
      queryClient.invalidateQueries({ queryKey: ['/api/personnel/stats'] });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Erreur d'import",
        description: error instanceof Error ? error.message : "Erreur inconnue",
        variant: "destructive"
      });
    }
  });

  const handleConfirmImport = () => {
    const cleanedData = data.map(({ rowIndex, ...rest }) => rest);
    confirmImportMutation.mutate(cleanedData);
  };

  if (!data || data.length === 0) return null;

  return (
    <Card className="mb-8">
      <CardHeader className="border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Eye className="text-amk-primary mr-3 h-5 w-5" />
            <h2 className="text-xl font-semibold text-gray-900">Prévisualisation des données</h2>
          </div>
          <div className="flex space-x-3">
            <Button 
              variant="outline" 
              onClick={onClose}
              className="text-red-600 border-red-300 hover:bg-red-50"
            >
              <X className="mr-2 h-4 w-4" />
              Annuler
            </Button>
            <Button 
              onClick={handleConfirmImport}
              disabled={confirmImportMutation.isPending}
              className="amk-secondary hover:bg-green-700 text-white"
            >
              {confirmImportMutation.isPending ? 'Import en cours...' : 'Valider l\'import'}
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-center">
            <AlertCircle className="text-blue-600 mr-3 h-5 w-5" />
            <div>
              <p className="text-blue-800 font-medium">{data.length} enregistrements détectés</p>
              <p className="text-blue-700 text-sm">Vérifiez les données avant de valider l'importation</p>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nom</TableHead>
                <TableHead>Prénom</TableHead>
                <TableHead>CIN</TableHead>
                <TableHead>Banque</TableHead>
                <TableHead>Montant</TableHead>
                <TableHead>Marché Cadre</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.slice(0, 10).map((person, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{person.nom}</TableCell>
                  <TableCell>{person.prenom}</TableCell>
                  <TableCell>{person.cin}</TableCell>
                  <TableCell>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      {person.banque}
                    </span>
                  </TableCell>
                  <TableCell>{person.montantPaiement} MAD</TableCell>
                  <TableCell>{person.numeroMarcheCadre}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          {data.length > 10 && (
            <p className="text-center text-gray-500 py-4">
              Et {data.length - 10} autres enregistrements...
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
