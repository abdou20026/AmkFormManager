import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Users, Search, Download, Plus, Edit, Trash2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Personnel } from "@shared/schema";
import { useState } from "react";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

interface PersonnelTableProps {
  onDeleteClick: (person: Personnel) => void;
  onAddClick: () => void;
}

export default function PersonnelTable({ onDeleteClick, onAddClick }: PersonnelTableProps) {
  const [searchQuery, setSearchQuery] = useState("");
  
  const { data: personnel = [], isLoading } = useQuery<Personnel[]>({
    queryKey: ['/api/personnel', searchQuery],
    queryFn: async () => {
      const url = searchQuery 
        ? `/api/personnel?search=${encodeURIComponent(searchQuery)}`
        : '/api/personnel';
      const response = await fetch(url, { credentials: 'include' });
      if (!response.ok) throw new Error('Erreur lors du chargement');
      return response.json();
    }
  });

  const getInitials = (nom: string, prenom: string) => {
    return `${nom.charAt(0)}${prenom.charAt(0)}`.toUpperCase();
  };

  const getBankColor = (banque: string) => {
    const colors = {
      'Attijariwafa Bank': 'bg-green-100 text-green-800',
      'BMCE Bank': 'bg-blue-100 text-blue-800',
      'Banque Populaire': 'bg-purple-100 text-purple-800',
      'Crédit du Maroc': 'bg-orange-100 text-orange-800',
      'CIH Bank': 'bg-red-100 text-red-800'
    };
    return colors[banque as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const handleExport = () => {
    window.open('/api/personnel/export/global', '_blank');
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center py-8">Chargement...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="border-b border-gray-200">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-1 flex items-center">
              <Users className="text-amk-primary mr-3 h-5 w-5" />
              Personnel enregistré
            </h2>
            <p className="text-gray-600">
              <span>{personnel.length}</span> enregistrements
              {personnel.length > 0 && (
                <>
                  {' • '}
                  Dernière mise à jour: {' '}
                  <span>
                    {formatDistanceToNow(new Date(personnel[0].createdAt || ''), { 
                      addSuffix: true, 
                      locale: fr 
                    })}
                  </span>
                </>
              )}
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative">
              <Input
                type="text"
                placeholder="Rechercher..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={handleExport}
                className="amk-secondary hover:bg-green-700 text-white"
              >
                <Download className="mr-2 h-4 w-4" />
                Exporter
              </Button>
              <Button 
                onClick={onAddClick}
                className="amk-primary hover:amk-primary-dark text-white"
              >
                <Plus className="mr-2 h-4 w-4" />
                Ajouter
              </Button>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nom complet</TableHead>
                <TableHead>CIN</TableHead>
                <TableHead>Banque</TableHead>
                <TableHead>Marché cadre</TableHead>
                <TableHead>Montant</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {personnel.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                    Aucun personnel enregistré
                  </TableCell>
                </TableRow>
              ) : (
                personnel.map((person) => (
                  <TableRow key={person.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div className="flex items-center">
                        <div className="w-10 h-10 amk-primary rounded-full flex items-center justify-center text-white font-medium mr-4">
                          {getInitials(person.nom, person.prenom)}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">
                            {person.prenom} {person.nom}
                          </div>
                          <div className="text-sm text-gray-500">
                            {person.email || 'Email non renseigné'}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-gray-900">{person.cin}</TableCell>
                    <TableCell>
                      <Badge className={getBankColor(person.banque)}>
                        {person.banque}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-gray-900">{person.numeroMarcheCadre}</TableCell>
                    <TableCell>
                      <div className="text-sm font-medium text-gray-900">
                        {person.montantPaiement} MAD
                      </div>
                      <div className="text-sm text-gray-500">
                        {person.statut || 'En attente'}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-blue-600 hover:text-blue-900 hover:bg-blue-50"
                          title="Modifier"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onDeleteClick(person)}
                          className="text-red-600 hover:text-red-900 hover:bg-red-50"
                          title="Supprimer"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {/* Pagination would go here if needed */}
        {personnel.length > 0 && (
          <div className="border-t border-gray-200 px-6 py-3 flex items-center justify-between">
            <div className="text-sm text-gray-700">
              Affichage de <span className="font-medium">1</span> à{' '}
              <span className="font-medium">{Math.min(10, personnel.length)}</span> sur{' '}
              <span className="font-medium">{personnel.length}</span> résultats
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
