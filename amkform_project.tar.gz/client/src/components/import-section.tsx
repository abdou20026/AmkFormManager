import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, Check, CloudUpload } from "lucide-react";
import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ImportSectionProps {
  onImportPreview: (data: any[]) => void;
}

export default function ImportSection({ onImportPreview }: ImportSectionProps) {
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const expectedColumns = [
    "Nom",
    "Prénom", 
    "CIN",
    "Compte bancaire",
    "Banque",
    "Numéro du marché cadre",
    "Montant du paiement"
  ];

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;

    const file = acceptedFiles[0];
    setIsUploading(true);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/personnel/import', {
        method: 'POST',
        body: formData,
        credentials: 'include'
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Erreur lors de l\'upload');
      }

      const result = await response.json();
      
      if (result.errors && result.errors.length > 0) {
        toast({
          title: "Erreurs détectées",
          description: `${result.validRows} lignes valides, ${result.errorRows} erreurs`,
          variant: "destructive"
        });
      } else {
        toast({
          title: "Import réussi",
          description: `${result.validRows} enregistrements prêts à être importés`
        });
      }

      onImportPreview(result.data || []);
    } catch (error) {
      toast({
        title: "Erreur d'import", 
        description: error instanceof Error ? error.message : "Erreur inconnue",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  }, [onImportPreview, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx']
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: false
  });

  return (
    <Card className="mb-8">
      <CardHeader className="border-b border-gray-200">
        <CardTitle className="flex items-center text-xl font-semibold text-gray-900">
          <Upload className="text-amk-primary mr-3 h-5 w-5" />
          Importation de données
        </CardTitle>
        <p className="text-gray-600">Importez vos données depuis un fichier Excel (.xlsx) ou Word (.docx)</p>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="grid md:grid-cols-2 gap-6">
          {/* File Upload Area */}
          <div>
            <div 
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                isDragActive 
                  ? 'border-amk-primary bg-blue-50' 
                  : 'border-gray-300 hover:border-amk-primary'
              }`}
            >
              <input {...getInputProps()} />
              <CloudUpload className="text-4xl text-gray-400 mb-4 h-16 w-16 mx-auto" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {isDragActive ? 'Déposez votre fichier ici' : 'Glissez votre fichier ici'}
              </h3>
              <p className="text-gray-600 mb-4">ou cliquez pour sélectionner</p>
              <Button 
                type="button" 
                className="amk-primary hover:amk-primary-dark text-white"
                disabled={isUploading}
              >
                {isUploading ? 'Import en cours...' : 'Parcourir'}
              </Button>
              <p className="text-sm text-gray-500 mt-2">
                Formats acceptés: .xlsx, .docx (max 10MB)
              </p>
            </div>
          </div>
          
          {/* Expected Columns Info */}
          <div className="bg-gray-50 rounded-lg p-6">
            <h4 className="font-medium text-gray-900 mb-4">Colonnes attendues:</h4>
            <ul className="space-y-2 text-sm text-gray-700">
              {expectedColumns.map((column, index) => (
                <li key={index} className="flex items-center">
                  <Check className="text-amk-secondary mr-2 h-4 w-4" />
                  {column}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
