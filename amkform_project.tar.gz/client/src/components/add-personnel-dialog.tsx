import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPersonnelSchema, MOROCCAN_BANKS } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { UserPlus } from "lucide-react";
import { z } from "zod";

interface AddPersonnelDialogProps {
  open: boolean;
  onClose: () => void;
}

const formSchema = insertPersonnelSchema.extend({
  email: z.string().email("Email invalide").optional().or(z.literal("")),
});

export default function AddPersonnelDialog({ open, onClose }: AddPersonnelDialogProps) {
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      nom: "",
      prenom: "",
      cin: "",
      compteBancaire: "",
      banque: "",
      numeroMarcheCadre: "",
      montantPaiement: "",
      email: "",
      statut: "En attente"
    }
  });

  const createMutation = useMutation({
    mutationFn: async (data: z.infer<typeof insertPersonnelSchema>) => {
      const response = await apiRequest('POST', '/api/personnel', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Personnel ajouté",
        description: "Le nouvel enregistrement a été créé avec succès"
      });
      queryClient.invalidateQueries({ queryKey: ['/api/personnel'] });
      queryClient.invalidateQueries({ queryKey: ['/api/personnel/stats'] });
      form.reset();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Erreur de création",
        description: error instanceof Error ? error.message : "Erreur inconnue",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    const submitData = {
      ...values,
      email: values.email || null
    };
    createMutation.mutate(submitData);
  };

  const handleClose = () => {
    form.reset();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 amk-primary rounded-full flex items-center justify-center mr-4">
              <UserPlus className="text-white h-6 w-6" />
            </div>
            <div>
              <DialogTitle className="text-xl font-semibold text-gray-900">
                Ajouter un nouveau personnel
              </DialogTitle>
              <DialogDescription className="text-gray-600">
                Saisissez les informations du personnel à ajouter
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Nom */}
              <FormField
                control={form.control}
                name="nom"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nom *</FormLabel>
                    <FormControl>
                      <Input placeholder="Nom de famille" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Prénom */}
              <FormField
                control={form.control}
                name="prenom"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prénom *</FormLabel>
                    <FormControl>
                      <Input placeholder="Prénom" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* CIN */}
              <FormField
                control={form.control}
                name="cin"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>CIN *</FormLabel>
                    <FormControl>
                      <Input placeholder="Numéro de CIN" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Email */}
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="adresse@email.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Compte Bancaire */}
              <FormField
                control={form.control}
                name="compteBancaire"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Compte Bancaire *</FormLabel>
                    <FormControl>
                      <Input placeholder="Numéro de compte" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Banque */}
              <FormField
                control={form.control}
                name="banque"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Banque *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner une banque" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {MOROCCAN_BANKS.map((bank) => (
                          <SelectItem key={bank} value={bank}>
                            {bank}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Numéro Marché Cadre */}
              <FormField
                control={form.control}
                name="numeroMarcheCadre"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Numéro du Marché Cadre *</FormLabel>
                    <FormControl>
                      <Input placeholder="Numéro du marché" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Montant Paiement */}
              <FormField
                control={form.control}
                name="montantPaiement"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Montant du Paiement *</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input 
                          type="number" 
                          step="0.01"
                          placeholder="0.00" 
                          {...field} 
                        />
                        <span className="absolute right-3 top-2.5 text-sm text-gray-500">MAD</span>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter className="flex gap-3">
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleClose}
                disabled={createMutation.isPending}
              >
                Annuler
              </Button>
              <Button 
                type="submit"
                disabled={createMutation.isPending}
                className="amk-primary hover:amk-primary-dark text-white"
              >
                {createMutation.isPending ? 'Ajout en cours...' : 'Ajouter'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}