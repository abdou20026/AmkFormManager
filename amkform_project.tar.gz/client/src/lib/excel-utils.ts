import * as XLSX from 'xlsx';

export interface ExcelColumn {
  key: string;
  header: string;
  variations: string[];
}

export const EXPECTED_COLUMNS: ExcelColumn[] = [
  {
    key: 'nom',
    header: 'Nom',
    variations: ['nom', 'name', 'lastname', 'famille']
  },
  {
    key: 'prenom',
    header: 'Prénom',
    variations: ['prénom', 'prenom', 'firstname']
  },
  {
    key: 'cin',
    header: 'CIN',
    variations: ['cin', 'id', 'carte identité', 'carte d\'identité']
  },
  {
    key: 'compteBancaire',
    header: 'Compte Bancaire',
    variations: ['compte bancaire', 'compte', 'account', 'bank account', 'numero compte']
  },
  {
    key: 'banque',
    header: 'Banque',
    variations: ['banque', 'bank', 'établissement']
  },
  {
    key: 'numeroMarcheCadre',
    header: 'Numéro du Marché Cadre',
    variations: ['numéro du marché cadre', 'numero marche cadre', 'marché cadre', 'marche cadre', 'contrat']
  },
  {
    key: 'montantPaiement',
    header: 'Montant du Paiement',
    variations: ['montant du paiement', 'montant paiement', 'montant', 'amount', 'prix', 'salaire']
  }
];

export function parseExcelFile(buffer: ArrayBuffer): any[][] {
  const workbook = XLSX.read(buffer, { type: 'buffer' });
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];
  return XLSX.utils.sheet_to_json(worksheet, { header: 1 });
}

export function findColumnIndexes(headers: string[]): Record<string, number> {
  const normalizedHeaders = headers.map(h => String(h).toLowerCase().trim());
  const columnIndexes: Record<string, number> = {};

  for (const column of EXPECTED_COLUMNS) {
    const index = normalizedHeaders.findIndex(header => 
      column.variations.some(variation => 
        header.includes(variation.toLowerCase())
      )
    );
    
    if (index !== -1) {
      columnIndexes[column.key] = index;
    }
  }

  return columnIndexes;
}

export function validateRequiredColumns(columnIndexes: Record<string, number>): string[] {
  const requiredFields = EXPECTED_COLUMNS.map(col => col.key);
  return requiredFields.filter(field => columnIndexes[field] === undefined);
}

export function createExcelFile(data: any[], filename: string): Blob {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Personnel');
  
  const buffer = XLSX.write(workbook, { type: 'array', bookType: 'xlsx' });
  return new Blob([buffer], { 
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
  });
}

export function downloadExcelFile(data: any[], filename: string): void {
  const blob = createExcelFile(data, filename);
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  URL.revokeObjectURL(url);
}

export function cleanCellValue(value: any): string {
  if (value === null || value === undefined) return '';
  return String(value).trim();
}

export function parseCurrency(value: string): string {
  if (!value) return '0';
  
  // Remove currency symbols and extra spaces
  const cleaned = value.toString()
    .replace(/[^\d.,\-]/g, '') // Keep only digits, dots, commas, and minus
    .replace(/,/g, '.') // Replace comma with dot for decimal
    .trim();
  
  // Handle empty or invalid values
  if (!cleaned || cleaned === '.' || cleaned === '-') return '0';
  
  return cleaned;
}

export function validatePersonnelData(data: any): {
  isValid: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  if (!data.nom || data.nom.trim().length === 0) {
    errors.push('Le nom est requis');
  }

  if (!data.prenom || data.prenom.trim().length === 0) {
    errors.push('Le prénom est requis');
  }

  if (!data.cin || data.cin.trim().length === 0) {
    errors.push('Le CIN est requis');
  }

  if (!data.compteBancaire || data.compteBancaire.trim().length === 0) {
    errors.push('Le compte bancaire est requis');
  }

  if (!data.banque || data.banque.trim().length === 0) {
    errors.push('La banque est requise');
  }

  if (!data.numeroMarcheCadre || data.numeroMarcheCadre.trim().length === 0) {
    errors.push('Le numéro du marché cadre est requis');
  }

  if (!data.montantPaiement || parseCurrency(data.montantPaiement) === '0') {
    errors.push('Le montant du paiement est requis');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}
