import { pgTable, text, serial, integer, boolean, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const personnel = pgTable("personnel", {
  id: serial("id").primaryKey(),
  nom: text("nom").notNull(),
  prenom: text("prenom").notNull(),
  cin: text("cin").notNull().unique(),
  compteBancaire: text("compte_bancaire").notNull(),
  banque: text("banque").notNull(),
  numeroMarcheCadre: text("numero_marche_cadre").notNull(),
  montantPaiement: decimal("montant_paiement", { precision: 10, scale: 2 }).notNull(),
  email: text("email"),
  statut: text("statut").default("En attente"),
  createdAt: text("created_at").default("now()"),
});

export const insertPersonnelSchema = createInsertSchema(personnel).omit({
  id: true,
  createdAt: true,
});

export type InsertPersonnel = z.infer<typeof insertPersonnelSchema>;
export type Personnel = typeof personnel.$inferSelect;

// Moroccan banks list
export const MOROCCAN_BANKS = [
  "Attijariwafa Bank",
  "BMCE Bank",
  "Banque Populaire",
  "Crédit du Maroc", 
  "CIH Bank",
  "Crédit Agricole du Maroc",
  "Al Barid Bank",
  "Bank Al-Maghrib",
  "Société Générale Maroc",
  "CFG Bank"
] as const;

export type MoroccanBank = typeof MOROCCAN_BANKS[number];
